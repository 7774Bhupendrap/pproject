



<html>
    <head>
        <title> 
            forgot password
        </title>
        <link rel="stylesheet" href="style1.css" type="text/css">
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    </head>
<body>
    <div class="wrapper">
        <form>
            <h1>Forgot password</h1>
            <h3>Enter your email id</h3>
<div class="input">
    <input type="email" placeholder="Email" required>
    <i class='bx bxs-envelope'></i>
</div>
<button type="submit" class="btn" onclick="login.html">Continue</button>
        </form>
        <div class="register_link">
            <p>Get back to <a href="login.php">login</a></p>
        </div>
    </div>
</body>

</html>